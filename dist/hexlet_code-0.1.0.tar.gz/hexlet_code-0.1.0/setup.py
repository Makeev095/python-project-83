# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer']

package_data = \
{'': ['*'], 'page_analyzer': ['templates/*']}

install_requires = \
['bs4>=0.0.1,<0.0.2',
 'flake8>=6.0.0,<7.0.0',
 'flask>=2.2.3,<3.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'load-dotenv>=0.1.0,<0.2.0',
 'postgres>=4.0,<5.0',
 'psycopg2-binary>=2.9.5,<3.0.0',
 'pytest>=7.2.1,<8.0.0',
 'validators>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '# PAGE ANALYZER\n\nPage Analyzer is a web application that checks web pages for SEO suitability.\nIn addition, you can get basic information from the main page of the site by running a check.\n\nYou can try the app by following the link:\nhttps://python-project-83-production-df71.up.railway.app\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Makeev095/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/Makeev095/python-project-83/actions)\n\n[![CI Check](https://github.com/Makeev095/python-project-83/workflows/main/badge.svg)](https://github.com/Makeev095/python-project-83/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/c275e15046e7cb6fd0a5/maintainability)](https://codeclimate.com/github/Makeev095/python-project-83/maintainability)\n',
    'author': 'Makeev095',
    'author_email': 'makeev095095@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
