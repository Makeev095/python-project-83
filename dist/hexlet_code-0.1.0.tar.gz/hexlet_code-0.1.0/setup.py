# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=6.0.0,<7.0.0', 'flask>=2.2.3,<3.0.0', 'gunicorn>=20.1.0,<21.0.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Makeev095/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/Makeev095/python-project-83/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/c275e15046e7cb6fd0a5/maintainability)](https://codeclimate.com/github/Makeev095/python-project-83/maintainability)\n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/c275e15046e7cb6fd0a5/test_coverage)](https://codeclimate.com/github/Makeev095/python-project-83/test_coverage)',
    'author': 'Makeev095',
    'author_email': 'makeev095095@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
