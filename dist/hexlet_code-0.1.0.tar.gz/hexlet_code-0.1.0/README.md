### Hexlet tests and linter status:
[![Actions Status](https://github.com/Makeev095/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/Makeev095/python-project-83/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/c275e15046e7cb6fd0a5/maintainability)](https://codeclimate.com/github/Makeev095/python-project-83/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/c275e15046e7cb6fd0a5/test_coverage)](https://codeclimate.com/github/Makeev095/python-project-83/test_coverage)

Domain: python-project-83-production-df71.up.railway.app