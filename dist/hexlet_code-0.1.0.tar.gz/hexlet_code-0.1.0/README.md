# PAGE ANALYZER

Page Analyzer is a web application that checks web pages for SEO suitability.
In addition, you can get basic information from the main page of the site by running a check.

You can try the app by following the link:
https://python-project-83-production-df71.up.railway.app

### Hexlet tests and linter status:
[![Actions Status](https://github.com/Makeev095/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/Makeev095/python-project-83/actions)

[![CI Check](https://github.com/Makeev095/python-project-83/workflows/main/badge.svg)](https://github.com/Makeev095/python-project-83/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/c275e15046e7cb6fd0a5/maintainability)](https://codeclimate.com/github/Makeev095/python-project-83/maintainability)
